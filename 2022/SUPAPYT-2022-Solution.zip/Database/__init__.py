'''Package for database reading and statistical analysis.'''

# So you can do
# from Database import Database
# rather than
# from Database.DB import Database
from Database.DB import Database
